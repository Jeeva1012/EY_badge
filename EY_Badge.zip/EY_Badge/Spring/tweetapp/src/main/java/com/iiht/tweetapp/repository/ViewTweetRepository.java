package com.iiht.tweetapp.repository;

import java.util.List;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.socialsignin.spring.data.dynamodb.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.iiht.tweetapp.model.TweetUser;

@Repository
@EnableScan
public interface ViewTweetRepository extends CrudRepository<TweetUser, String> {

	List<TweetUser> findAllByUsername(String username);

	void deleteByusernameAndId(String username,String id);

	TweetUser findByUsernameAndId(String username, String id);

    //@Query("{'username':{'$regex':'?0','$options':'i'}}")  
    //List<TweetUser> searchByUsername(String username);


	
}
