package com.iiht.tweetapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.tweetapp.model.TweetUser;
import com.iiht.tweetapp.service.PostTweetService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1.0/tweets")
public class PostTweetController {

	@Autowired
	PostTweetService postTweetService;
	
	@PostMapping("/{username}/add")
	public TweetUser postTweet(@PathVariable String username,@RequestBody TweetUser tweetuser) {
		return postTweetService.postTweet(username,tweetuser);
	}
}
