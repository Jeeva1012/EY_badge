package com.iiht.tweetapp.model;


import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;

public class UserRequest {
	
	private String id;
	private String username;
	private String httpMethod;
	private RegisterUser registerUser;
	private String newPassword;
	private TweetUser tweetUser;
	private ReplyUser replyUser;
	private String updateTweet;
	private String tweetId;
	
	
			

	public String getTweetId() {
		return tweetId;
	}

	public void setTweetId(String tweetId) {
		this.tweetId = tweetId;
	}

	public String getUpdateTweet() {
		return updateTweet;
	}

	public void setUpdateTweet(String updateTweet) {
		this.updateTweet = updateTweet;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public ReplyUser getReplyUser() {
		return replyUser;
	}

	public void setReplyUser(ReplyUser replyUser) {
		this.replyUser = replyUser;
	}

	public TweetUser getTweetUser() {
		return tweetUser;
	}

	public void setTweetUser(TweetUser tweetUser) {
		this.tweetUser = tweetUser;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public RegisterUser getRegisterUser() {
		return registerUser;
	}

	public void setRegisterUser(RegisterUser registerUser) {
		this.registerUser = registerUser;
	}

	@DynamoDBHashKey
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public UserRequest(String id) {
		super();
		this.id = id;
	}

	public UserRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	

}
