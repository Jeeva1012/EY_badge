package com.iiht.tweetapp.repository;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.iiht.tweetapp.model.TweetUser;

@EnableScan
@Repository
public interface TweetRepository extends CrudRepository<TweetUser, Integer>{

	TweetUser findByUsername(String username);
	
}
