package com.iiht.tweetapp.handlers;


import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBSaveExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedScanList;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ExpectedAttributeValue;
import com.amazonaws.services.dynamodbv2.model.UpdateItemRequest;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.iiht.tweetapp.model.RegisterUser;
import com.iiht.tweetapp.model.UserRequest;


public class LambdaFunctionHandler implements RequestHandler<UserRequest, Object> {

    @Override
    public Object handleRequest(UserRequest request, Context context) {
        context.getLogger().log("Received event: " + request);
        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.defaultClient();
        DynamoDBMapper mapper = new DynamoDBMapper(client);
        PaginatedScanList<RegisterUser> register =null;
        RegisterUser postUser = null;
        
        switch(request.getHttpMethod()) {
        case "GET":
        	register = mapper.scan(RegisterUser.class, new DynamoDBScanExpression());
        	if(register==null) {
        		return new Exception();
        	}
        	return register;
        case "POST":
        	postUser=request.getRegisterUser();
        	mapper.save(postUser);
        	return postUser;
        case "PUT":
        String UpdatePass = request.getNewPassword();
        RegisterUser findById = mapper.load(RegisterUser.class,request.getId());
        	findById.setPassword(UpdatePass);
        	return postUser;	
        default:
        	break;
        }
        return null;
		
	}


    
}