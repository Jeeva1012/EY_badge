package com.iiht.tweetapp.handlers;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.iiht.tweetapp.model.RegisterUser;
import com.iiht.tweetapp.model.UserRequest;

public class GetWidgetHandler implements RequestHandler<UserRequest, RegisterUser>{
	@Override
    public RegisterUser handleRequest(UserRequest userRequest, Context context) {
        //return new Widget(widgetRequest.getId(), "My Widget " + widgetRequest.getId());

        // Create a connection to DynamoDB
        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.defaultClient();
        DynamoDB dynamoDB = new DynamoDB(client);

        // Get a reference to the Widget table
        Table table = dynamoDB.getTable("Widget");

        // Get our item by ID
        Item item = table.getItem("id", userRequest.getId());
        if(item != null) {
            System.out.println(item.toJSONPretty());

            // Return a new Widget object
            return new RegisterUser();
        }
        else {
            return new RegisterUser();
        }
    }

}
