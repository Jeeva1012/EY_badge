
import React, { Component } from 'react'
import ApiService from '../service/ApiService';
import HomeComponent from './HomeComponent';

class ViewTweetsHome extends Component {

    constructor(props) {
        super(props)
        this.state = {
            username:'',
            tweets: [],
            message: '',
            
            
        }
        
        this.reloadTweetList = this.reloadTweetList.bind(this);
    }

    componentDidMount() {
        this.reloadTweetList();
        //this.state.likeCount=  this.likeTweet();
        
    }

    reloadTweetList() {
        this.setState({username:window.localStorage.getItem("username")})
        //axios.get('http://localhost:8091/api/v1.0/tweets/users/all')
        ApiService.fetchTweets()
            .then((res) => {
                console.log(res)
                this.setState({tweets: res.data})
                
            })
            .catch(error =>{
                console.log(error)
                this.setState({message:'Error retreving data'})
            })
            setTimeout(() => this.setState({message:''}), 3000);
    }

    likeTweet(id,username){

        ApiService.fetchUserByIdAndUsername(id,username)
            .then((res) => {
                let user = res.data.result;
               console.log(user)
               window.localStorage.setItem("tweetCount",res.data)
               this.reloadTweetList();
            });
        
    }

    edittweet(id,username) {
        console.log(id);
        console.log(username);
        window.localStorage.setItem("tweetId", id);
        window.localStorage.setItem("tweetUsername", username);
        this.props.history.push('/updateTweet');
    }

    deletetweet(id,username) {
        console.log(id);
        console.log(username);
        ApiService.deleteTweet(id,username)
            .then(res => {
                this.setState({message : 'deleted successfully.'});
                this.reloadTweetList();
            });
    }

    render() {
     
       
        const { tweets,message } = this.state
        
        var reply = this.state.reply
        return (
            
            <div align = "left">
             <HomeComponent/>
                <h2 className="text-center">Tweet</h2>
                    {
                    tweets.length ? tweets.map(tweet => 
                        <div class="card-body msg_card_body">
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
							  
                                    <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQDxUPDxAQEBUQEA8VEBUQDxAPEBAQFRUWFhUXFRUYHSggGBomGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy0lICYtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABAUBAgMGBwj/xABDEAACAQEDCAcFBgQEBwAAAAAAAQIDBBEhBRITMUFRYXEGIjJSgZGhFEKxwdEHI3KSk+EVU4KiYsLw8SRDVGR0g7L/xAAbAQEAAgMBAQAAAAAAAAAAAAAABQYBAwQCB//EADMRAAICAAIHBwMEAgMAAAAAAAABAgMEEQUSEyExQVEyYXGBkbHRIqHBFCPh8AYzJELx/9oADAMBAAIRAxEAPwD7EAACbT1LkjY1p6lyRsARLR2vI5nS0dryOYB3su3wJBHsz1+HzK+3ZehDqw+8lwfVXjt8DVdfXTHWseSPddcrHlFZllaOz4lXaMpUoa5XvdHrMoLZlKrV7csO7HCP7kUhL9N8qY+b+P5JKrRvOx+nyXVXL79yC5yfyRFq5bry9/N5JIrwRlmkMTPjN+W72O6GEpjwivPedp22pLtVJv8AqZxc3vfmwDlc5S4tvzZuUIrgvYKT3vzOtO1VI9mpNcpM5AKclwb9WZcU+K9idSyxXj/zG/xJSJUOkEn24J8YtxfkU4OmvH4iHCb89/uaJ4WmXGKPTWfK1Ke3Ne6WHrqLOza71uPCney2ypSd9OTjw1x8iSo03JbrY596+Djt0av+j9fk96aVuyyksPSGMurWWY+8sY+O4uHNShemmmsGnemTdGJqvWdbz9/QjLKZ1vKayIwAN5rJ4AAIVXtPmam1XtPmagAAAEvRR3IzoluRuACHKo02k9rGklvZrPW+b+JgAk0oqSveL4nC22mlRjnTuW5LW3wRGt2VI0IXa5u+6PzfA8rabRKpLOm22/TluIvH6SjR9EN8vsvH4O3C4N2/VLcvfwJeUMqTq4LqR7qevm9pBAKxbbO2WtN5sm6641rViskAAaz2AAAAAAGDBkAAAAAwADJJsVvnRfVeG2Lxi/oRgeoWShLWg8meZQU1lJZo9hk630qywSUlri9fhvRYaNbkfP6c3FqUW008GsGj1ORssKp93Uwnseyf7llwGlFc9SzdLryf893oQ2KwTr+qG9exN0st7M6SW9mgJgjyTGCaTaTv1m+iW5Cl2VyNwDTRLcjB0ABF9ofD1HtD4epyABIVFPHHHEr8r2uNCOGM5dlYeb4Eu2WuNGlny2JXLa3sR4u02iVSbnN3tvwW5Ii9JY/YR1Idp/ZdTtweF2rzl2V9+41qVHJuUne3rbMAIqjbbzZPJZAAAAAAAAAAAAAAGMzOQABkwAAAAAADCZkAHpMiW9Vfu6jeetT7y+pc+zre/Q8FCTTvTuaxTWtM9jkfKKrQx7UcJL5rgWbReP2q2Vna5PqQmNwuzevHh7El1HHBXYGPaHw9TSr2nzNSZI86+0Ph6g5AA7ezvevIOhxRJKfpHbMynmRfWqYco7TVfdGmt2S4I911uyaiuZRZYt2mqXLswwjx3sggFJttlbNzlxZZa4KEVFcEAYMo1nsAAAAAAHOvWjTi5zlGEYpuUpNKMUtbbZ0PhXTnpPVtlonBScaNObjTgncnmu7Olvbav4HbgcFLFTaTyS4s5sTiFTHPm+B6npD9p6jJ07DBSud2lrJ3PjGC2cX5Hird0vt9bt2ur/62qS/sSKEwWenA4epZRivF739yEsxNtj3v8Fl/GrV/1Vp/Xq/UusmdPLdRfWrOtHbGrc/KWv4nkwbpUVSWTivQ8K2cXmpM+69GOmtK2LNfUml1oNrO5rvLkepjJNXrFPUfmmzV5U5xnTk4yi04tO5pn2roT0iVpoqTwaebVjsjPeuD1lf0jo1VLaV8OnQlsJjHP6J8fc9cACFJEAAAAAAHew2t0ainHZrW+O1HAHqMnCSlHijEoqSyfA9xSuqRU4tXSxRt7O968ik6MW3XRk+MPmvmekLrhMQr6lNefiVq+p1TcH/URvZ3v9GCSDoNRydaO/0Z4vKlp0taU9l90fwr/XqX+Va+ZRk9r6q5v9rzyxX9NX741Lxf4JbRtXGx+CAAIAlQEAAAAAAAAVnSS1ujYq9WDulChVcXulmu5+Z8c6FdEK2Vas4wkqcacXKpVmnJKb7Mbr7227+VzZ9d6Ywvydal/wBtVflFv5D7GLCqeSYVEsbRVrTk9rzZumv/AIfmWHRD1aZtcc/wRWNjrWxXLI+QdIOgtvsTbq2eU4J4VaP3tNrf1cY/1JHmLj9gFdbsgWSu769ks1V750acpebV5Kq/qjklhujPyhcdaNGU5KMIynJ6lFOUnySP07HoXk1O/wBgsvjRi15MtbFk+jQV1CjSordSpwpr0R6266HlYZ9T8yZS6K22zUI2m0WapSpzkoqU81POabV8b86OrW0j3/2YKPssGoq/TTU3djJ34N78Gl4H0vprkv2vJ1ooXXuVGbp3/wA2Cz4f3JLxPlv2Xv8A4Vf+Q/8AKcWPk5Yd+Jvw9epcvA+lgAqhNgAAAAAAAAG1Cq4TjOOuLTR7ihaYyipJ9pJ6ntPCnoOj9e+m4PXB+j/0ya0Nfq2Op8+Hiv49iN0lVnBTXL2L/TR3+jBEMlkzRDFH0jq4xhzk/gvmUxPy/VzrRL/DdHyX7kApukLNfEzffl6bix4SGrTFAAHGdAAAAAAAAABCyzR0lmrU+/Z60fODRc9FLB7PYLPQ1OnZ6Sl+Jxvl6tkM9DF4Jk9oxZUt9X7HBie35GTBkwSJpBkAAyfLejmTXZZVKclcvbbVm37YKq4xflFH1E8l0juz8MOtL5X+pz4pZ0yQr7aZLBpT7Kv3K/yNysEqAAAAAABcAACwyFVurXd9NeOtfArzpZKmbUhLdKL9TfhrNndGfRo1XQ165R7j2Obz9QTMN/qC760SsbzwlvnnVZvfUl8WcDNR4t8X8QUOb1pN979y1QWUUjAMmDyegAZAAAAAAABdWGpnU1wwfgUpNyXVuk4Pbq5kho69ws1G9z9znxEM463NFsYBgnjhQBkGTJzrVFCLm9UYtvkleeQpX15upPBJ4Ljr+hc9J7Xm01SWuo8fwrX63EGyUsyCjt28yJ0je19CZ0YeGbzZ2ABDHaAAAYMgwAZMGQAYMmDIBe/xTiZKG8Hd+vsOP9FAzPW+bMHS1xzak1unJepzOOayk13v3OqLzimAAeT0AAAAAAAAABGVzvWwFpkiwX/eTWHup7eLOjC4ed9ihD/xGq+2NUHKRIstdTjft2rczqRLfY5U3paWC95LZ+xyhlPvR8mWmUHF5EXCaks0WBrUmopyeCRCllNbIvxZizUZ2iV8sIJ7PgjEYtvJGZSSWbPP2qq6lrvlvVy3JRvRPLLL2Rc+KqUVm1KawS9+K2c9xS2S0Z63SXaRA6Sw067M3wZ24S6NkNxIABGnWAAAAAAAAAAAAAWn8O4A6v0dvQ5v1dZxy5TzbRPi014pEEuOk0b5xnddfFp81/uU5nHV6mImu/P1M4WetTF9wAByHQYMmDIAAIVvt8aSu7UnqX1NlNM7pqFazbPFlka4603kiZeRK+Uacfeznuh1v2KK02ydTtSw3LCPkRpO5eBZMP8A4+uN8vJfPwQ12lnwqXm/gzb+ktWV6p3U1jirpTfi9R7/AKE5Y9qsqz3fUo9Spvfdl4r1TPkt28vOh2V/ZbVFyd0Kt0Km5JvCXg/S8mK8LVTHVril/epHyvnZLObzPr5SZUydm31Kaw95LZxXAu0VPSLLMbLTwulUmupH/NLh8TGy2n0oxLERoi7JPJIiZOsDqu94RWt7+CPQQgopJK5LUlsPM9E8vaVKhVaU1fmO5JVFuu73xPTh0up6r4mK8XHFQVkOH3XcyDl3KSstnnXl7seou9N4RXmfI6OW6ym6jlnuTbd6Wt6y/wDtHyvpKyssH1aGM9zqtfJP1Z489uiFkMrEmu8bWUJZxeR7Wx5aUknNXXpO9cSxo2iE+zJP0Z4+y9hcjvGTWpkTiP8AH6pb6pZdz3r5R31aWmt1iz8NzPXgobHlSSwl1lx+TLulVUlfF3/IreJwtuHlq2Imab4XR1oM3ABzm4AAAHSzwzpxivecV5s5k7IdO+vF3X5t8n4avU3YeGvbGPVr3NdstSDl0R7HRrcDn7Rw9QXXZxKzmypy1Qz6L3w6y8Nfo2eaPcaB6ndjxPG22zunUlB+68OTxXoQOm6MpRtXPc/wS2jbdzrfj8nEwZBBEoYMmDIBxtddU4Ob2LDi9h5apNyblLFt3sucvz6sY75N+S/cpC4aBw8Y0bXnJ/ZFd0ra5W6nJe4ABPEYQ8ozV2bhe+GpEAn5RpXrOWzXyIBrZlH1voDlP2uzKMnfOhdCpvcfcl4pXc0yo6eWOMbSnGTvnCLknjdc7ld5ajzPQjLXsdsjKTup1bqdX8LeEvB48ry/6XWjSW2pujmpf0rH1bPeFh+9u6EbpuxLC7+Oay9/Yq8l2ZSr04yk0nUgm44SWK1PYz6P0ltysdnnXeNyugu9UfZXn6HzWnUzZKfdlGXk7yf9p+WtNXjZYO+FDGd2p1pL5Rd3izZjYZyj5nN/j9n0WLnmjxdWo5ScpNuUm3JvW23eyTk+ok813Y6ndiRSVk6le857NXM0ImyxABsMGSyyZas2WOp4S+TKw62d4+BGaVojbh23xW87MBa67kup6wHGzSvhF74o7FEay3FpQAAAL3o7RujKb953Lktfr8CihByaitbaS5vBHtLLY3CEYK7qpbdb2kvoajXudj4R93/BH6Rt1a1Dr7AHTQPh5gtBCEsoOk9izoqqljHCX4d/h8y80i3rzRrUUZJxbTTTTx2M0YmhXVOD5myqx1zUkeABJyjZHSqOOzXF74kYpM4Srk4S4ossJKSUlwYMgHk9FL0geMFwl8voVBa5ffXj+D5lUXzRMf8Ah1+H5Krj3/yJ/wB5A0jPrSjuuNyJQn99Jb/kSLTOTNEpq9XMp61PNk47tXIuSJlCles5a46+QabCaK8u8n2lzj1nfJa23e3xZSXnew18yad+DwfJnqmThM4dJYZX0NLit6+PQuLVWzIOXlxewoZSbbbd7bbbeLbZLyrXzpZqeEfiQz3iJOUslwRp0RhtjTrvjLf5chFXu5bS4o082Kju18yFk6le857MFzLA0pMlG0aVZ3LnKK9TciZQncor/Ff5Eu8ykxmgdKHa8zmb0X1jRi03RNdzNtD/AHY+J6awP7qPj8WdyLk1/dLnL4ks+dz7TLfHgYBk3oUXOShFXuTuMJNvJcQ2ks2W3Rmx503VawhhHjL9l8T1REsVGNKnGCaWascbsdpJz1vXmi6YLDfp6lDnxfiVzEXO2xy9PA2BppFvXmgdRoIYAANMp2FV6SXvJXwfHceOqQcW4yVzTaa3M+gw1Lkiny5krSLSU111rXfX1IfSmAdq2kO0uXVfJIYLFbN6kuD+x5YGGjJWCbOc6cXrinzSZjQQ7kfyxOoPSnJcG/U8uEXyOegh3Iflia+zU779HC/8ETsBtJdX6sakeiOWhh3IfliNBDuQ/LE6gztJdX6sakeiI/stP+VT/Tj9B7JT/lU/04/QkC4bSXV+rGpHoji7JT/l0/04/Q19jp/yqf6cfoSAY2kur9WNSPT7I5KzwWChBf0R+hnQw7kfyx+h0BnaT6v1Y1I9F6HCVmpvXTg+cIm2hh3IflidQY2kur9WNSPRHPQQ7kfyxMaGPcj+VHUDaT6v1Y1V0RrFJaklywNgGeT0D1WQcmaKOkmuvJau7HdzIeQckX3Vqiw9yL28WekLForAav71i38l+fgh8fitb9uHn8EOr2nzNTar2nzNSdIwAAAnXC4yACFJ4vmzGc9782J63zfxMAFflPI+ljpKeE9q2T/c83KLTaauawaeDTPfUOz5kHKmS4Vlf2Z7JL570Q2P0Wrc7Kt0ua5MkMLjXX9M+HsePB2tlinRlmzjdua7L5M4lalGUG4yWTJqMlJZrgADBgyZAAAQAAAAAAAAAAAABvQoSqSzYJyb3GUm3kg2ks2aF9kXIt91SsuMYvbxl9CZknIsaV06l0p7O7HlvfEuCw4DRWq1Zfx5L5+CHxWO1vor9fgh5z3vzMZz3vzZgE6RhMpLqrkbXGtLsrkbgGLgZABD00t/ohppb/RGgAJMaaava18WbaGO71ZtT1LkjYAjVJOLujgvM000t/ojNo7XkcwDo6aqpqolJbmU1v6PPtUX/TJ/B/UvLLt8CQc2IwlWIWU15815m6q+yp5xfwfPq1GUHmzi4virvI1PdWylGUbpRUsdqvKa0ZEg+w3D+5EFfoWyO+p59z3P4JOrSUH21l90eeBYVcjVV2Up/hePkyJVstSHapzjziyMsw1tfbi15HbC6ufZkn5nIAGk2gAxeAZBvTs85dmEpcotkunkes9cczm0vQ210W2diLfkzXO2EO00iCIQcndFNt6kk2/JF5QyFFYzm5cF1V5lxYLNCDuhFRw2LHzJKjQ1099j1V6v4OO3SNcews/siksPR6csarzFuWMn9C/oWOFKN1OObd4t895LNK3ZZO4bBU4fsLf1fH++BF3Yiy3tPy5EbTS3+iGmlv8ARGgOs0EvQx3erGhju9WdAARZVGncngtWo100t/ojFXtPmagG+mlv9EDQAAAAE2nqXJGwABEtHa8jmAAd7Lt8CQAAcrR2fFEZAAwbUta5kreAZXAPkedyxtKGWsAp+kf9hO4DsGpcZJ1oA14H/ajZjf8AUeqhqOFp1oyC5rslf5nE6WbX4AAwSjSt2WYAMkQAAE8AAEKr2nzNQAAAAD//2Q==" class="rounded-circle user_img_msg"/>
								</div>
								<div class="msg_cotainer">
                                <h6 >@{tweet.username}</h6>
                                <div>{tweet.tweet}							
                                    
								</div>
                                
                                <div class="msg_time">{tweet.timeAgo}</div>
							</div>
                            
                        </div>
                        
                        
                                            </div>
                        
                        
                        ): null
                    }
                    
                    {
                        message ? <div>{message}</div> : null
                    }
           
            </div>
            
        )
        
    }

}

export default ViewTweetsHome;