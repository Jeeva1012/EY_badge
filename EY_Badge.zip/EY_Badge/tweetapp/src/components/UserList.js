
import React, { Component } from 'react'
import ApiService from '../service/ApiService';
import HeaderComponent from './HeaderComponent';

class UserList extends Component {

    constructor(props) {
        super(props)
        this.state = {
            users: [],
            message: ''
        }
        
        this.reloadUserList = this.reloadUserList.bind(this);
    }

    componentDidMount() {
        this.reloadUserList();
    }

    reloadUserList() {
        //axios.get('http://localhost:8091/api/v1.0/tweets/users/all')
        ApiService.fetchUsers()
            .then((res) => {
                console.log(res)
                this.setState({users: res.data})
            })
            .catch(error =>{
                console.log(error)
                this.setState({message:'Error retreving data'})
            })
    }

    
    render() {
     
        const { users,message } = this.state
        return (
            <div>
                <HeaderComponent/>
                <h2 className="text-center">User List</h2>
                    {
                    users.length ? users.map(user => <li key={user.id}>{user.email}</li>):null
                       
                    }
                    {
                        message ? <div>{message}</div> : null
                    }
                
            </div>
        )
    }

}

export default UserList;