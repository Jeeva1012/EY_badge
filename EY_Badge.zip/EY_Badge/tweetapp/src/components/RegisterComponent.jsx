import React, { Component } from "react";
import ApiService from "../service/ApiService.jsx";
import HomeComponent from "./HomeComponent.js";

class RegisterComponent extends Component {
    constructor(props){
        super(props);
        this.state ={
            input: {},
      errors: {},
      message:'',
      error:''
        }
        this.saveUser = this.saveUser.bind(this);
        this.changeHandler = this.changeHandler.bind(this);

    }

    saveUser = (e) => {
        e.preventDefault();
        if(this.validate()){
            console.log(this.state);
            console.log(this.state)
            let user =this.state.input
            console.log(user)
            ApiService.addUser(user)
           
           
                .then(res => {
                    console.log(res)
                    this.setState({message : 'User added successfully.' })
                    this.props.history.push('/login');
                })
                .catch(err=> {
                  this.setState({error : 'EmailId already Exist' })
                  alert('EmailId already Exist or Invalid input');
    
                }
                  
                  )
            let input = {};
            input["firstName"] = "";
            input["lastName"] = "";
            input["email"] = "";
            input["password"] = "";
            input["confirm_password"] = "";
            input["contactNumber"] = "";
            this.setState({input:input});
      
            alert('Demo Form is submited');
        }
        
    }

    changeHandler(event) {
    let input = this.state.input;
    input[event.target.name] = event.target.value;
  
    this.setState({
      input
    });
    }
        validate(){
            let input = this.state.input;
            let errors = {};
            let isValid = true;
        
            if (!input["firstName"]) {
              isValid = false;
              errors["firstName"] = "Please enter your firstName.";
            }

            if (!input["lastName"]) {
                isValid = false;
                errors["lastName"] = "Please enter your lastName.";
              }
        
            if (!input["email"]) {
              isValid = false;
              errors["email"] = "Please enter your email Address.";
            }
        
            if (typeof input["email"] !== "undefined") {
                
              var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
              if (!pattern.test(input["email"])) {
                isValid = false;
                errors["email"] = "Please enter valid email address.";
              }
            }
        
            if (!input["password"]) {
              isValid = false;
              errors["password"] = "Please enter your password.";
            }
        
            if (!input["confirm_password"]) {
              isValid = false;
              errors["confirm_password"] = "Please enter your confirm password.";
            }
        
            if (typeof input["password"] !== "undefined" && typeof input["confirm_password"] !== "undefined") {
                
              if (input["password"] != input["confirm_password"]) {
                isValid = false;
                errors["password"] = "Passwords don't match.";
              }
            } 

            if (!input["contactNumber"]) {
                isValid = false;
                errors["contactNumber"] = "Please enter your contactNumber.";
              }
        
            this.setState({
              errors: errors
            });
        
            return isValid;
        }
    
    render() {
        const { firstName, lastName, email, password, confirm_password,contactNumber } = this.state
        return (
            <div>
                <HomeComponent/>
            <form className="auth-wrapper-register">
                <h3>Register</h3>

                <div className="form-group">
                    <label>First name</label>
                    <input type="text" className="form-control" placeholder="First name" name="firstName" value={firstName}  onChange={this.changeHandler} />
                </div>

                <div className="text-danger">{this.state.errors.firstName}</div>
        

                <div className="form-group">
                    <label>Last name</label>
                    <input type="text" className="form-control" placeholder="Last name" name="lastName" value={lastName} onChange={this.changeHandler}/>
                </div>

                <div className="text-danger">{this.state.errors.lastName}</div>

                <div className="form-group">
                    <label>Email address</label>
                    <input type="email" className="form-control" placeholder="Enter email" name="email" value={email}  onChange={this.changeHandler}/>
                </div>

                <div className="text-danger">{this.state.errors.email}</div>

                <div className="form-group">
                    <label>Password</label>
                    <input type="password" className="form-control" placeholder="Enter password" name="password" value={password} onChange={this.changeHandler}/>
                </div>

                <div className="text-danger">{this.state.errors.password}</div>

                <div className="form-group">
                    <label>Confirm Password</label>
                    <input type="password" className="form-control" placeholder="Enter password again" name="confirm_password" value={confirm_password} onChange={this.changeHandler}/>
                </div>

                <div className="text-danger">{this.state.errors.confirm_password}</div>

                <div className="form-group">
                    <label>Contact Number</label>
                    <input type="password" className="form-control" placeholder="Enter contactNumber" name="contactNumber" value={contactNumber} onChange={this.changeHandler}/>
                </div>

                <div className="text-danger">{this.state.errors.contactNumber}</div>

                <button type="submit" className="btn btn-primary btn-block" onClick={this.saveUser}>Register</button>
                <p className="forgot-password text-right">
                    Already registered <a href="/login">Login?</a>
                </p>
            </form>
            </div>
        );
    }
}

export default RegisterComponent;