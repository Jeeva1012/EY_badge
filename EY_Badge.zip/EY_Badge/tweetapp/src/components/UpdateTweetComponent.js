import React, { Component } from 'react'
import ApiService from '../service/ApiService';
import HeaderComponent from './HeaderComponent';

class UpdateTweetComponent extends Component {

    constructor(props){
        super(props);
        this.state ={
            tweet: window.localStorage.getItem("tweet")
        }
        this.saveUser = this.saveUser.bind(this);
        this.loadUser = this.loadUser.bind(this);
    }

    componentDidMount() {
        this.loadUser();
    }

    loadUser() {
        ApiService.updateUserByIdAndUsername(window.localStorage.getItem("tweetId"),window.localStorage.getItem("tweetUsername"))
            .then((res) => {
                let user = res.data.result;
                this.setState({
                    tweet:user.tweet
                
                })
            });
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    saveUser = (e) => {
        e.preventDefault();
        let user = {tweet:this.state.tweet};
        ApiService.editUser(window.localStorage.getItem("tweetId"),window.localStorage.getItem("tweetUsername"),user)
            .then(res => {
                this.setState({message : 'updated successfully.'});
                this.props.history.push('/allTweet');
            });
    }

    render() {
        return (
            <div>
                <HeaderComponent/>
                <h2 className="text-center">Edit Tweet</h2>
                <form>

                    <div className="form-group">
                        <label>Tweet:</label>
                        <input type="text" placeholder={this.state.tweet} name="tweet" className="form-control" value={this.state.tweet} onChange={this.onChange}/>
                    </div>

                    
                    <button className="btn btn-success" onClick={this.saveUser}>Save</button>
                </form>
            </div>
        );
    }
}

export default UpdateTweetComponent;