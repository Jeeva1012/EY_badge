import axios from 'axios';

const USER_API_BASE_URL = 'http://3.108.8.230:8091/api/v1.0/tweets';

class ApiService {

    fetchUsers() {
        return axios.get('http://3.108.8.230:8091/api/v1.0/tweets/users/all');
    }

    fetchTweets(){
        return axios.get('http://3.108.8.230:8091/api/v1.0/tweets/all');
    }
    fetchMyTweet(username) {
        return axios.get(USER_API_BASE_URL + '/' + username+'/' + 'all');
    }

    fetchUserByIdAndUsername(id,username){
        return axios.put('http://3.108.8.230:8091/api/v1.0/tweets'+'/'+username+'/'+'like'+'/'+id)
    }

    updateUserByIdAndUsername(id,username){
        return axios.put('http://3.108.8.230:8091/api/v1.0/tweets'+'/'+username+'/'+'update'+'/'+id)
    }

    deleteTweet(id,username) {
        return axios.delete(USER_API_BASE_URL + '/' +username+'/'+'delete'+ '/' + id);
    }

    addUser(user) {
        return axios.post('http://3.108.8.230:8091/api/v1.0/tweets/register', user);
    }

    addPost(user,username){
        return axios.post('http://3.108.8.230:8091/api/v1.0/tweets'+'/'+username+'/'+'add',user)
    }

    login(username,password){


        var basicAuth= 'Basic ' + window.btoa(username + ':' + password);
        console.log(basicAuth);
        return axios.get('http://3.108.8.230:8091/api/v1.0/tweets/login',{headers:{'Authorization':basicAuth}});
    }

    editUser(tweetId,tweetUsername,user) {
        return axios.put(USER_API_BASE_URL + '/' + tweetUsername+ '/'+'update' +'/' +tweetId, user);
    }

    forgot(username,password){
        return axios.get(USER_API_BASE_URL + '/' + username+ '/'+'forgot'+'?'+'newpassword'+'='+password);
    }

    search(username){  
        return axios.get(USER_API_BASE_URL + '/' +'users'+'/' + 'search' + '/' + username)
    }

    postReplyTweet(username,replyTweet,tweetId){
        return axios.post(USER_API_BASE_URL+ '/'+ username+'/' + 'reply' + '/'+ tweetId,replyTweet)

    }

    getReplyTweet(loginId){
        return axios.get(USER_API_BASE_URL + '/' + loginId)
    }
}

export default new ApiService();